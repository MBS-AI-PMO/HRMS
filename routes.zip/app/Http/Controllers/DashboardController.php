<?php

namespace App\Http\Controllers;

use App\Http\traits\AutoUpdateTrait;
use App\Http\traits\CalendarableModelTrait;
use App\Http\traits\ENVFilePutContent;
use App\Http\traits\ShiftTimingOnDay;
use App\Models\Announcement;
use App\Models\Attendance;
use App\Models\Award;
use App\Models\location;
use App\Services\AttendanceOvertimeService;
use App\Services\EntityDashboardService;
use App\Services\ProjectTimelineService;
use App\Support\ClientDisplay;
use App\Support\CompanyScope;
use App\Support\ManagedEmployeeScope;
use App\Models\Client;
use App\Models\company;
use App\Models\DocumentType;
use App\Models\Employee;
use App\Models\EmployeeProject;
use App\Models\EmployeeTask;
use App\Models\EmployeeTicket;
use App\Models\EmployeeWorkExperience;
use App\Models\FinanceDeposit;
use App\Models\FinanceExpense;
use App\Models\GeneralSetting;
use App\Models\Holiday;
use App\Models\Invoice;
use App\Models\IpSetting;
use App\Models\leave;
use App\Models\LeaveType;
use App\Models\Payslip;
use App\Models\Project;
use App\Models\QualificationEducationLevel;
use App\Models\QualificationLanguage;
use App\Models\QualificationSkill;
use App\Models\RelationType;
use App\Models\SalaryBasic;
use App\Models\status;
use App\Models\SupportTicket;
use App\Models\Trainer;
use App\Models\TrainingType;
use App\Models\TravelType;
use App\Models\User;
use Carbon\Carbon;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Validator;
use Spatie\Permission\Models\Role;
use Throwable;
use ZipArchive;


class DashboardController extends Controller {

    use CalendarableModelTrait, AutoUpdateTrait, ENVFilePutContent;

    private ?array $versionUpgradeInfo = null;

	public function __construct()
    {
		$this->middleware(['auth']);
	}

    protected function loadVersionUpgradeInfo(): array
    {
        if ($this->versionUpgradeInfo !== null) {
            return $this->versionUpgradeInfo;
        }

        try {
            if (! config('database.connections.peopleprosaas_landlord')) {
                $this->versionUpgradeInfo = $this->isUpdateAvailable();
            } else {
                $this->versionUpgradeInfo = ['alert_version_upgrade_enable' => false];
            }
        } catch (Throwable $e) {
            report($e);
            $this->versionUpgradeInfo = ['alert_version_upgrade_enable' => false];
        }

        return $this->versionUpgradeInfo;
    }


	public function hrDashboard()
	{
        if (! $this->canAccessHrDashboard()) {
            return redirect()->route('employee.EmployeeDashboard');
        }

        return $this->renderHrDashboard();
	}

    public function executiveDashboard()
    {
        if ((int) auth()->user()->role_users_id !== 1) {
            abort(403, __('You are not authorized'));
        }

        $versionUpgradeData = $this->loadVersionUpgradeInfo();
        $metrics = $this->buildExecutiveDashboardMetrics();

        return view('dashboard.executive_dashboard', compact('metrics', 'versionUpgradeData'));
    }

    public function companyDashboard(int $id)
    {
        if (! auth()->user()->can('view-company')) {
            abort(403, __('You are not authorized'));
        }

        CompanyScope::assertCompanyAccess($id);

        app(ProjectTimelineService::class)->syncAll();

        $company = company::query()
            ->with(['Location.Country', 'companyType:id,type_name'])
            ->findOrFail($id);

        $dashboard = app(EntityDashboardService::class)->buildCompanyDashboard($company);

        return view('dashboard.entity_dashboard', compact('dashboard'));
    }

    public function clientOverviewDashboard(int $id)
    {
        if (! auth()->user()->can('view-client')) {
            abort(403, __('You are not authorized'));
        }

        $client = Client::query()->findOrFail($id);

        app(ProjectTimelineService::class)->syncAll();

        $dashboard = app(EntityDashboardService::class)->buildClientDashboard($client);

        return view('dashboard.entity_dashboard', compact('dashboard'));
    }

    protected function canAccessHrDashboard(): bool
    {
        $user = auth()->user();
        $roleId = (int) $user->role_users_id;

        if (in_array($roleId, [1, 2], true)) {
            return true;
        }

        return $user->can('view-details-employee');
    }

    protected function renderHrDashboard()
	{
        $versionUpgradeData = $this->loadVersionUpgradeInfo();

		$employees = Employee::with('department:id,department_name', 'designation:id,designation_name')
			->select('id', 'department_id', 'designation_id', 'is_active')
			->where('is_active', '=', 1)->where('is_active',1)
            ->where('exit_date',NULL)->get();

		$departments = $employees->groupBy('department_id');


		$dept_count_array = [];
		$dept_name_array = [];
		$dept_bgcolor_array = [];
		$dept_hover_bgcolor_array = [];
		$deptColorIndex = 0;

		if ($departments)
		{
			foreach ($departments as $key => $dept)
			{
				$colors = $this->hrChartColorForIndex($deptColorIndex++);
				$dept_bgcolor_array[] = $colors['bg'];
				$dept_hover_bgcolor_array[] = $colors['hover'];

				$dept_count_array[] = $dept->count();
				if ($key == null)
				{
					$dept_name_array[] = __('No Department');
				} else
				{
					$dept_name_array[] = $dept->first()->department->department_name;
				}
			}
		}


		$designations = $employees->groupBy('designation_id');

		$desig_count_array = [];
		$desig_name_array = [];
		$desig_bgcolor_array = [];
		$desig_hover_bgcolor_array = [];
		$desigColorIndex = 0;

		if ($designations)
		{
			foreach ($designations as $key => $desig)
			{
				$colors = $this->hrChartColorForIndex($desigColorIndex++);
				$desig_bgcolor_array[] = $colors['bg'];
				$desig_hover_bgcolor_array[] = $colors['hover'];
				$desig_count_array[] = $desig->count();
				if ($key == null)
				{
					$desig_name_array[] = __('No Designation');
				} else
				{
					$desig_name_array[] = $desig->first()->designation->designation_name;
				}
			}
		}

		$attendance_count = Attendance::where('attendance_date', now()->format('Y-m-d'))->distinct('employee_id')->count();


		$leave_count = leave::where('start_date', '<=', now()->format('Y-m-d'))
			->where('end_date', '>=', now()->format('Y-m-d'))->count();

		$total_expense_raw = FinanceExpense::sum('amount');
		$total_deposit_raw = FinanceDeposit::sum('amount');
		$total_salaries_paid = Payslip::sum('net_salary');


		if (config('variable.currency_format') == 'suffix')
		{
			// $total_expense = $total_expense_raw . config('variable.currency');
            $total_expense = number_format((float)$total_expense_raw, 3, '.', '') . config('variable.currency');
			$total_deposit = $total_deposit_raw . config('variable.currency');
			$total_salaries_paid = $total_salaries_paid . config('variable.currency');

		} else
		{
			// $total_expense = config('variable.currency') . $total_expense_raw;
			$total_expense = config('variable.currency') . number_format((float)$total_expense_raw, 3, '.', '');
			$total_deposit = config('variable.currency') . $total_deposit_raw;
			$total_salaries_paid = config('variable.currency') . $total_salaries_paid;
		}


		$months = [];
		for ($i = 0; $i < 6
		; $i++)
		{
			$months[] = date("F-Y", strtotime(date('Y-m-01') . " -$i months"));
		}

		$payslips = Payslip::all('id', 'net_salary', 'month_year');

		for ($i=5; $i >=0 ; $i--) {
			$payslips_last_six_months[$months[$i]] = $payslips->where('month_year', $months[$i])->sum('net_salary');
		}

		$per_month_payment = array_values($payslips_last_six_months);
		$per_month = array_keys($payslips_last_six_months);


		$this_month_payment = $payslips->where('month_year', date('F-Y'))->sum('net_salary');
		$last_six_month_payment = $payslips->whereIn('month_year', $months)->sum('net_salary');


		$companies = company::select('id', 'company_name')->get();
		LeaveType::firstOrCreate(
            ['leave_type' => 'WFH'],
            ['allocated_day' => 365, 'company_id' => null]
        );
		$leave_types = LeaveType::select('id', 'leave_type', 'allocated_day')->get();
		$travel_types = TravelType::select('id', 'arrangement_type')->get();
		$training_types = TrainingType::select('id', 'type')->get();
		$trainers = Trainer::select('id', 'first_name', 'last_name')->get();
		// $clients = Client::select('id', 'name')->get();
		$clients = Client::select('id', 'first_name','last_name')->get();

		$projects = Project::select('id', 'title', 'project_status')->get();

		$normalizedProjectCounts = [
			'completed' => 0,
			'in_progress' => 0,
			'not_started' => 0,
			'deferred' => 0,
		];

		foreach ($projects as $project) {
			$status = strtolower(trim((string) ($project->project_status ?? '')));

			if (in_array($status, ['not started', 'not_started'], true)) {
				$normalizedProjectCounts['not_started']++;
			} elseif (isset($normalizedProjectCounts[$status])) {
				$normalizedProjectCounts[$status]++;
			}
		}

		$projectStatusConfig = [
			['key' => 'completed', 'label' => __('Completed'), 'color' => '#19AED9'],
			['key' => 'in_progress', 'label' => __('In Progress'), 'color' => '#37205B'],
			['key' => 'not_started', 'label' => __('Not Started'), 'color' => '#BF8CFF'],
			['key' => 'deferred', 'label' => __('Deferred'), 'color' => '#F4605B'],
		];

		$project_count_array = [];
		$project_name_array = [];
		$project_color_array = [];

		foreach ($projectStatusConfig as $statusConfig) {
			$project_count_array[] = $normalizedProjectCounts[$statusConfig['key']];
			$project_name_array[] = $statusConfig['label'];
			$project_color_array[] = $statusConfig['color'];
		}

		$completed_projects = $normalizedProjectCounts['completed'];

		$announcements = Announcement::where('start_date', '<=', now()->format('Y-m-d'))
			->where('end_date', '>=', now()->format('Y-m-d'))->select('id', 'title', 'summary')->get();

		$ticket_count = SupportTicket::where('ticket_status', 'open')->count();


		return view('dashboard.admin_dashboard', compact('employees', 'attendance_count', 'leave_count', 'total_expense_raw', 'total_deposit_raw', 'total_expense', 'total_deposit', 'total_salaries_paid',
			'dept_count_array', 'dept_name_array', 'dept_bgcolor_array', 'dept_hover_bgcolor_array',
			'desig_count_array', 'desig_name_array', 'desig_bgcolor_array', 'desig_hover_bgcolor_array',
			'payslips', 'companies', 'leave_types',
			'training_types', 'trainers', 'travel_types', 'clients', 'projects',
			'project_count_array', 'project_name_array', 'project_color_array', 'completed_projects',
			'announcements', 'ticket_count', 'per_month', 'per_month_payment', 'months', 'this_month_payment', 'last_six_month_payment',
            'versionUpgradeData'
        ));
	}

    protected function hrChartColorForIndex(int $index): array
    {
        $palette = [
            ['bg' => 'rgba(91, 74, 154, 0.85)', 'hover' => '#5b4a9a'],
            ['bg' => 'rgba(55, 32, 91, 0.85)', 'hover' => '#37205b'],
            ['bg' => 'rgba(191, 140, 255, 0.85)', 'hover' => '#BF8CFF'],
            ['bg' => 'rgba(25, 174, 217, 0.85)', 'hover' => '#19AED9'],
            ['bg' => 'rgba(244, 96, 91, 0.85)', 'hover' => '#F4605B'],
            ['bg' => 'rgba(16, 185, 129, 0.85)', 'hover' => '#10b981'],
            ['bg' => 'rgba(245, 158, 11, 0.85)', 'hover' => '#f59e0b'],
            ['bg' => 'rgba(124, 92, 196, 0.85)', 'hover' => '#7c5cc4'],
        ];

        return $palette[$index % count($palette)];
    }

    protected function buildExecutiveDashboardMetrics(): array
    {
        $today = now()->format('Y-m-d');
        $thisMonthStart = now()->copy()->startOfMonth()->format('Y-m-d');
        $lastMonthStart = now()->copy()->subMonth()->startOfMonth()->format('Y-m-d');
        $lastMonthEnd = now()->copy()->subMonth()->endOfMonth()->format('Y-m-d');

        $activeEmployeesQuery = Employee::query()
            ->where('is_active', 1)
            ->whereNull('exit_date');

        $totalEmployees = (clone $activeEmployeesQuery)->count();
        $newEmployeesThisMonth = Employee::query()
            ->whereDate('joining_date', '>=', $thisMonthStart)
            ->count();
        $newEmployeesLastMonth = Employee::query()
            ->whereBetween('joining_date', [$lastMonthStart, $lastMonthEnd])
            ->count();

        $totalClients = Client::query()->count();
        $activeClients = Client::query()->where('is_active', 1)->count();
        $newClientsThisMonth = Client::query()->where('created_at', '>=', $thisMonthStart)->count();
        $newClientsLastMonth = Client::query()
            ->whereBetween('created_at', [$lastMonthStart, $lastMonthEnd.' 23:59:59'])
            ->count();

        $totalProjects = Project::query()->count();
        $projectStatusCounts = $this->countProjectsByStatus();
        $runningProjects = $projectStatusCounts['in_progress'];
        $completedProjects = $projectStatusCounts['completed'];
        $newProjectsThisMonth = Project::query()->where('created_at', '>=', $thisMonthStart)->count();
        $newProjectsLastMonth = Project::query()
            ->whereBetween('created_at', [$lastMonthStart, $lastMonthEnd.' 23:59:59'])
            ->count();

        $totalLocations = location::query()->count();
        $totalCompanies = company::query()->count();
        $newCompaniesThisMonth = company::query()->where('created_at', '>=', $thisMonthStart)->count();
        $newCompaniesLastMonth = company::query()
            ->whereBetween('created_at', [$lastMonthStart, $lastMonthEnd.' 23:59:59'])
            ->count();

        $locationsWithClient = location::query()->whereNotNull('client_id')->count();

        $attendanceToday = Attendance::query()
            ->whereDate('attendance_date', $today)
            ->distinct('employee_id')
            ->count('employee_id');
        $attendanceRate = $totalEmployees > 0
            ? round(($attendanceToday / $totalEmployees) * 100, 1)
            : 0;

        $pendingLeaves = leave::query()->where('status', 'pending')->count();
        $openTickets = SupportTicket::query()->where('ticket_status', 'open')->count();

        $monthLabels = [];
        $employeeGrowthSeries = [];
        $clientGrowthSeries = [];
        $companyGrowthSeries = [];
        $projectGrowthSeries = [];

        for ($i = 5; $i >= 0; $i--) {
            $month = now()->copy()->subMonths($i);
            $monthLabels[] = $month->format('M Y');
            $monthStart = $month->copy()->startOfMonth()->format('Y-m-d');
            $monthEnd = $month->copy()->endOfMonth()->format('Y-m-d');

            $employeeGrowthSeries[] = Employee::query()
                ->whereBetween('joining_date', [$monthStart, $monthEnd])
                ->count();
            $clientGrowthSeries[] = Client::query()
                ->whereBetween('created_at', [$monthStart, $monthEnd.' 23:59:59'])
                ->count();
            $companyGrowthSeries[] = company::query()
                ->whereBetween('created_at', [$monthStart, $monthEnd.' 23:59:59'])
                ->count();
            $projectGrowthSeries[] = Project::query()
                ->whereBetween('created_at', [$monthStart, $monthEnd.' 23:59:59'])
                ->count();
        }

        $topClients = Client::query()
            ->select('id', 'company_name', 'first_name', 'last_name', 'is_active')
            ->withCount('projects')
            ->whereHas('projects')
            ->orderByDesc('projects_count')
            ->limit(8)
            ->get()
            ->map(function (Client $client) {
                return [
                    'name' => ClientDisplay::label($client),
                    'projects_count' => (int) $client->projects_count,
                    'is_active' => (bool) $client->is_active,
                ];
            })
            ->values();

        $topCompanies = company::query()
            ->select('id', 'company_name')
            ->withCount('projects')
            ->whereHas('projects')
            ->orderByDesc('projects_count')
            ->limit(8)
            ->get()
            ->map(fn ($company) => [
                'type' => 'company',
                'name' => $company->company_name,
                'projects_count' => (int) $company->projects_count,
                'is_active' => null,
            ]);

        $topProjectOwners = $topCompanies
            ->merge($topClients->map(fn ($client) => [
                'type' => 'client',
                'name' => $client['name'],
                'projects_count' => $client['projects_count'],
                'is_active' => $client['is_active'],
            ]))
            ->sortByDesc('projects_count')
            ->values()
            ->take(10)
            ->values();

        $companyHierarchy = $this->buildCompanyClientProjectHierarchy();

        $departmentHeadcount = DB::table('employees')
            ->join('departments', 'employees.department_id', '=', 'departments.id')
            ->where('employees.is_active', 1)
            ->whereNull('employees.exit_date')
            ->groupBy('departments.id', 'departments.department_name')
            ->select('departments.department_name', DB::raw('COUNT(*) as total'))
            ->orderByDesc('total')
            ->limit(8)
            ->get()
            ->map(fn ($row) => [
                'department' => $row->department_name,
                'total' => (int) $row->total,
            ])
            ->values();

        return [
            'totals' => [
                'employees' => $totalEmployees,
                'clients' => $totalClients,
                'active_clients' => $activeClients,
                'projects' => $totalProjects,
                'running_projects' => $runningProjects,
                'completed_projects' => $completedProjects,
                'locations' => $totalLocations,
                'locations_with_client' => $locationsWithClient,
                'companies' => $totalCompanies,
                'attendance_today' => $attendanceToday,
                'attendance_rate' => $attendanceRate,
                'pending_leaves' => $pendingLeaves,
                'open_tickets' => $openTickets,
            ],
            'growth' => [
                'employees' => $this->growthPercent($newEmployeesLastMonth, $newEmployeesThisMonth),
                'clients' => $this->growthPercent($newClientsLastMonth, $newClientsThisMonth),
                'companies' => $this->growthPercent($newCompaniesLastMonth, $newCompaniesThisMonth),
                'projects' => $this->growthPercent($newProjectsLastMonth, $newProjectsThisMonth),
                'new_employees_this_month' => $newEmployeesThisMonth,
                'new_clients_this_month' => $newClientsThisMonth,
                'new_companies_this_month' => $newCompaniesThisMonth,
                'new_projects_this_month' => $newProjectsThisMonth,
            ],
            'charts' => [
                'month_labels' => $monthLabels,
                'employee_growth' => $employeeGrowthSeries,
                'client_growth' => $clientGrowthSeries,
                'company_growth' => $companyGrowthSeries,
                'project_growth' => $projectGrowthSeries,
                'project_status' => $projectStatusCounts,
            ],
            'top_clients' => $topClients,
            'top_companies' => $topCompanies->values(),
            'top_project_owners' => $topProjectOwners,
            'company_hierarchy' => $companyHierarchy,
            'department_headcount' => $departmentHeadcount,
        ];
    }

    protected function normalizeProjectStatus(?string $status): string
    {
        $status = strtolower(trim((string) $status));

        if ($status === '' || in_array($status, ['not started', 'not_started'], true)) {
            return 'not_started';
        }

        return $status;
    }

    protected function countProjectsByStatus(): array
    {
        $counts = [
            'in_progress' => 0,
            'not_started' => 0,
            'completed' => 0,
            'deferred' => 0,
        ];

        foreach (Project::query()->select('project_status')->cursor() as $project) {
            $status = $this->normalizeProjectStatus($project->project_status);

            if (isset($counts[$status])) {
                $counts[$status]++;
            }
        }

        return $counts;
    }

    protected function growthPercent(float|int $previous, float|int $current): float
    {
        $previous = (float) $previous;
        $current = (float) $current;

        if ($previous <= 0) {
            return $current > 0 ? 100.0 : 0.0;
        }

        return round((($current - $previous) / $previous) * 100, 1);
    }

    protected function buildCompanyClientProjectHierarchy()
    {
        $projects = Project::query()
            ->select('id', 'title', 'client_id', 'company_id', 'project_status')
            ->with('client:id,company_name,first_name,last_name,is_active')
            ->get();

        return company::query()
            ->select('id', 'company_name')
            ->orderBy('company_name')
            ->get()
            ->map(function ($company) use ($projects) {
                $companyProjects = $projects->where('company_id', $company->id);
                $clientIds = $companyProjects->pluck('client_id')->filter()->unique();

                $clients = Client::query()
                    ->select('id', 'company_name', 'first_name', 'last_name', 'is_active')
                    ->whereIn('id', $clientIds)
                    ->get()
                    ->map(function (Client $client) use ($companyProjects) {
                        $clientProjects = $companyProjects->where('client_id', $client->id)->values();

                        return [
                            'id' => $client->id,
                            'name' => ClientDisplay::label($client),
                            'projects_count' => $clientProjects->count(),
                            'projects' => $clientProjects->map(fn ($project) => [
                                'id' => $project->id,
                                'title' => $project->title,
                                'status' => $this->normalizeProjectStatus($project->project_status),
                                'status_label' => ucwords(str_replace('_', ' ', $this->normalizeProjectStatus($project->project_status))),
                            ])->values(),
                        ];
                    })
                    ->sortByDesc('projects_count')
                    ->values();

                return [
                    'id' => $company->id,
                    'name' => $company->company_name,
                    'clients_count' => $clients->count(),
                    'total_projects' => $companyProjects->count(),
                    'clients' => $clients,
                ];
            })
            ->filter(fn ($company) => $company['total_projects'] > 0 || $company['clients_count'] > 0)
            ->sortByDesc('total_projects')
            ->values();
    }

    public function newVersionReleasePage()
    {
		// Below line is deprecated, this code is needed for the client version 1.5.1 and below
        $this->dataWriteInENVFile('APP_ENV', 'local');
		// Below line is deprecated, this code is needed for the client version 1.5.1 and below

        $versionUpgradeData = $this->loadVersionUpgradeInfo();

        return view('version_upgrade.index', compact('versionUpgradeData'));
    }

    public function versionUpgrade() {
        $versionUpgradeData = $this->loadVersionUpgradeInfo();
        $message = 'Version Upgraded Successfully !!!';
        $version_upgrade_file_url = $versionUpgradeData['version_upgrade_file_url'];

        try {
            //Check file is exist
            $header_array = @get_headers($version_upgrade_file_url);
            if(!strpos($header_array[0], '200')) {
                throw new Exception("Something wrong. Please contact with support team.");
            }

            $this->fileTransferProcess($version_upgrade_file_url);

            if ($versionUpgradeData['latest_version_db_migrate_enable']==true){
                Artisan::call('migrate --path=database/migrations/primary');
                Artisan::call('migrate --path=database/migrations/modify');
            }

            Artisan::call('optimize:clear');

            $this->dataWriteInENVFile('VERSION', $versionUpgradeData['demo_version']);

            $this->setSuccessMessage($message);
            return redirect()->back();

        }
        catch(Exception $e) {
            return redirect()->back()->withErrors($e->getMessage());
        }
    }

    public function fileTransferProcess($version_upgrade_file_url)
    {
        $remote_file_name = pathinfo($version_upgrade_file_url)['basename'];
        $local_file = base_path('/'.$remote_file_name);
        $copy = copy($version_upgrade_file_url, $local_file);
        if ($copy) {
            // ****** Unzip ********
            $zip = new ZipArchive;
            $file = base_path($remote_file_name);
            $res = $zip->open($file);
            if ($res === TRUE) {
                $zip->extractTo(base_path('/'));
                $zip->close();

                // ****** Delete Zip File ******
                File::delete(base_path($remote_file_name));
            }
        }
    }


	public function profile()
	{

		$user = auth()->user();
         $companies = company::select('id', 'company_name')->get();
        $roles = Role::where('id', '!=', 3)->where('is_active', 1)->select('id', 'name')->get();
        $currentDate = date('Y-m-d');
		$employee = Employee::find($user->id);

		if (!$employee)
		{
			if ($user->role_users_id == 3)
			{
				return view('profile.client_profile', compact('user'));
			}

			return view('profile.user_profile', compact('user','companies','roles','currentDate'));
		} else
		{
			$statuses = status::select('id', 'status_title')->get();

			$countries = DB::table('countries')->select('id', 'name')->get();
			$document_types = DocumentType::select('id', 'document_type')->get();

			$education_levels = QualificationEducationLevel::select('id', 'name')->get();
			$language_skills = QualificationLanguage::select('id', 'name')->get();
			$general_skills = QualificationSkill::select('id', 'name')->get();
            $relationTypes = RelationType::select('id','type_name')->get();
			$salary_basics = SalaryBasic::where('employee_id', $employee->id)
                                        ->orderByRaw('DATE_FORMAT(first_date, "%y-%m")')
                                        ->get();

			return view('profile.employee_profile', compact('user', 'employee', 'statuses','roles','currentDate',
				'countries', 'document_types', 'education_levels', 'language_skills', 'general_skills', 'relationTypes', 'salary_basics','companies'));
		}
	}

	public function profile_update(Request $request, $id)
	{

		if (!env('USER_VERIFIED'))
		{
			return redirect()->back()->with('msg', 'This feature is disabled for demo!');
		}
		$user = User::findOrFail($id);

		$validator = Validator::make($request->all(),
			[
				'first_name' => 'required|unique:users,first_name,' . $id,
				'last_name' => 'required|unique:users,last_name,' . $id,
				'username' => 'required|unique:users,username,' . $id,
				'email' => 'required|email|unique:users,email,' . $id,
				'contact_no' => 'required|unique:users,contact_no,' . $id,
				'profile_photo' => 'nullable|image|max:10240|mimes:jpeg,png,jpg,gif',
			]
		);


		if ($validator->fails())
		{
			return redirect()->back()->withErrors($validator)->withInput();
		}
		$photo = $request->profile_photo;


		if (isset($photo))
		{
			$new_user = $request->username;
			if ($photo->isValid())
			{
				$file_name = preg_replace('/\s+/', '', $new_user) . '_' . time() . '.' . $photo->getClientOriginalExtension();
				$photo->storeAs('profile_photos', $file_name);
				$user->profile_photo = $file_name;
			}
		}

		$username = strtolower(trim($request->username));
		$contact_no = $request->contact_no;
		$email = strtolower(trim($request->email));

		$user->first_name = $request->first_name;
		$user->last_name = $request->last_name;
		$user->username = $username;
		$user->contact_no = $contact_no;
		$user->email = $email;

		$user->save();

		if ($user->role_users_id == 3)
		{
			Client::whereId($user->id)->update(['username' => $username, 'contact_no' => $contact_no,
				'email' => $email]);
			$this->setSuccessMessage(__('User Info Updated'));

			return redirect()->route('clientProfile');
		}

		if (Employee::whereKey($user->id)->exists()) {
			Employee::whereKey($user->id)->update([
				'first_name' => $request->first_name,
				'last_name' => $request->last_name,
				'email' => $email,
				'contact_no' => $contact_no,
			]);
		}

		$this->setSuccessMessage(__('User Info Updated'));

		return redirect()->route('profile');
	}

	public function employeeProfileUpdate(Request $request, $id)
	{

		$validator = Validator::make($request->only('first_name', 'last_name', 'email', 'contact_no', 'gender'
		),
			[
				'first_name' => 'required',
				'last_name' => 'required',
				'email' => 'required|email|unique:users,email,' . $id,
				'contact_no' => 'required|numeric|unique:users,contact_no,' . $id,
				'gender' => 'required',
			]
		);


		if ($validator->fails())
		{
			return response()->json(['errors' => $validator->errors()->all()]);
		}

		$data = [];
		$data['first_name'] = $request->first_name;
		$data['last_name'] = $request->last_name;
		$data['gender'] = $request->gender;
		$data ['marital_status'] = $request->marital_status;

		$data ['address'] = $request->address;
		$data ['city'] = $request->city;
		$data['state'] = $request->state;
		$data ['country'] = $request->country;
		$data ['zip_code'] = $request->zip_code;


		$data['email'] = strtolower(trim($request->email));
		$data['contact_no'] = $request->contact_no;


		$user = [];

		$user['email'] = strtolower(trim($request->email));
		$user['contact_no'] = $request->contact_no;


		DB::beginTransaction();
			try
			{
				User::whereId($id)->update($user);

				employee::whereId($id)->update($data);

				DB::commit();
			} catch (Exception $e)
			{
				DB::rollback();
				return response()->json(['error' =>  $e->getMessage()]);
			} catch (Throwable $e)
			{
				DB::rollback();
				return response()->json(['error' => $e->getMessage()]);
			}

			return response()->json(['success' => __('Data Added successfully.')]);
	}


	public function change_password(Request $request, $id)
	{

		if (!env('USER_VERIFIED'))
		{
			return redirect()->back()->with('msg', 'This feature is disabled for demo!');
		}

        if (! auth()->check()) {
            abort(401, __('Unauthenticated.'));
        }

		$user = User::findOrFail($id);

		$validator = Validator::make($request->all(),
			[
				'password' => 'required|min:4|confirmed',
			]
		);


		if ((int) auth()->id() !== (int) $id && (int) auth()->user()->role_users_id !== 1 && ! auth()->user()->can('modify-details-employee')) {
			return redirect()->route('profile')->with([
				'msg' => __('You are not authorized'),
				'type' => 'danger',
			])->withFragment('ChangePassword');
		}

		if ($validator->fails())
		{
			return redirect()->route('profile')->withErrors($validator)->withInput()->withFragment('ChangePassword');
		}


		$user->password = bcrypt($request->password);
		$user->save();

		$this->setSuccessMessage(__('Password has been changed'));

		return redirect('login')->with(Auth::logout());

	}


	protected function getIp($ip)
    {
        $data  = [];
        $data  = str_split($ip);
        $length= strlen($ip).'<br>';

        $count = 0;
        $get_ip ="";
        for ($i=0; $i < $length ; $i++) {
            if ($data[$i]=='.') {
                $count++;
            }
            $get_ip .= $data[$i];
            if ($count==3) {
                break;
            }
        }

        return $get_ip;
    }


	public function employeeDashboard(Request $request)
	{
		$general_setting = GeneralSetting::first();
		$user = auth()->user();
		$employee = Employee::with(
			'department:id,department_name',
			'designation:id,designation_name',
			'officeShift'
		)->find($user->id);

		if (! $employee) {
			Auth::logout();

			return redirect()->route('login')
				->with('error', __('Employee record not found. Please contact administrator.'));
		}

		$current_day_in = strtolower(Carbon::now()->format('l')).'_in';
		$current_day_out = strtolower(Carbon::now()->format('l')).'_out';

		$officeShift = $employee->officeShift;
		$shift_in = $officeShift ? ($officeShift->{$current_day_in} ?? null) : null;
		$shift_out = $officeShift ? ($officeShift->{$current_day_out} ?? null) : null;
		$shift_name = $officeShift?->shift_name ?? __('N/A');

		$announcements = Announcement::where('start_date', '<=', now()->format('Y-m-d'))
			->where('end_date', '>=', now()->format('Y-m-d'))->where('is_notify', 1)->select('id', 'title', 'summary')->latest()->take(3)->get();

		$employee_award_count = Award::where('employee_id', $user->id)->count();

		$holidays = Holiday::where('is_publish', 1)
			->where('end_date', '>=', now()->format('Y-m-d'))
			->where('company_id', $employee->company_id)
			->select('id', 'event_name', 'start_date', 'end_date')->latest()->take(3)->get();

		LeaveType::firstOrCreate(
            ['leave_type' => 'WFH'],
            ['allocated_day' => 365, 'company_id' => null]
        );
		$leave_types = LeaveType::select('id', 'leave_type', 'allocated_day')->get();
		$travel_types = TravelType::select('id', 'arrangement_type')->get();


		$assigned_projects = EmployeeProject::with(['assignedProjects' => function ($query) use ($employee)
		{
			$query->where('project_status', '!=', 'completed')->select('id', 'title', 'project_status');
		},])
			->where('employee_id', $employee->id)->get();
		// $assigned_projects_count = $assigned_projects->count();
        $assigned_projects_count = 0;
        foreach($assigned_projects as $task){
            if (count($task->assignedProjects)!=0) {
                $assigned_projects_count++;
            }
        }


		$assigned_tasks = EmployeeTask::with(['assignedTasks' => function ($query) use ($employee)
		{
			$query->where('task_status', '!=', 'completed')->select('id', 'task_name', 'task_status');
		},])
           ->where('employee_id', $employee->id)->get();

		// $assigned_tasks_count = $assigned_tasks->count();
        $assigned_tasks_count = 0;
        foreach($assigned_tasks as $task){
            if (count($task->assignedTasks)!=0) {
                $assigned_tasks_count++;
            }
        }


		$assigned_tickets = EmployeeTicket::with(['assignedTickets' => function ($query) use ($employee)
		{
			$query->where('ticket_status', '=', 'open')->select('id', 'subject', 'ticket_code', 'ticket_status');
		},])
			->where('employee_id', $employee->id)->get();

        //$assigned_tickets_count = $assigned_tickets->count();
        $assigned_tickets_count = 0;
        foreach($assigned_tickets as $ticket){
            if (count($ticket->assignedTickets)!=0) {
                $assigned_tickets_count++;
            }
        }



		$employee_attendance = Attendance::where('attendance_date', now()->format('Y-m-d'))
				->where('employee_id', $employee->id)->orderBy('id', 'desc')->first() ?? null;

		$shift_ended = $shift_out ? AttendanceOvertimeService::isShiftEnded($shift_out) : false;
		$is_off_day = AttendanceOvertimeService::isOffDay($shift_in, $shift_out);
		$can_overtime_clock_in = $is_off_day
			? AttendanceOvertimeService::canOvertimeOnOffDay($employee_attendance)
			: ($shift_out && AttendanceOvertimeService::canStartOvertime($shift_out, $employee_attendance));
		$is_on_overtime_session = AttendanceOvertimeService::isActiveOvertimeSession($employee_attendance);
		$today_overtime_total = AttendanceOvertimeService::sumTodayOvertime($employee->id, now()->format('Y-m-d'));
		$is_past_shift_while_clocked_in = $shift_ended
			&& $employee_attendance
			&& (int) $employee_attendance->clock_in_out === 1
			&& ! $is_on_overtime_session;

		$is_location_head = location::userCanAccessMyLocationsPage((int) $user->id)
			&& (
				$user->can('location-head-access')
				|| $user->can('view-my-locations')
				|| $user->can('scoped-view-employees')
				|| $user->can('scoped-manage-leave')
				|| $user->can('report-clock-in-locations')
			);
		$location_head_employee_count = $is_location_head
			? count(location::employeeIdsAtLocationsHeadedByUser((int) $user->id))
			: 0;
		$can_manage_location_scope = ManagedEmployeeScope::canAccessScopedEmployeeList(
			(int) $user->id,
			(int) $user->role_users_id
		);

		//IP Check

        $ip_setting = IpSetting::get();

        if (count($ip_setting)==0) {
            $ipCheck =  false;
        }else {
            foreach ($ip_setting as $key => $value) {
                $db_ip = $this->getIp($value->ip_address);

                $client_ip = $this->getIp($request->ip());

                if ($db_ip==$client_ip) {
                    $ipCheck =  true;
                    break;
                }else {
                    $ipCheck =  false;
                }
            }
        }
		return view('dashboard.employee_dashboard', compact('user', 'employee', 'employee_attendance',
			'shift_in', 'shift_out', 'shift_name', 'announcements',
			'employee_award_count', 'holidays', 'leave_types', 'travel_types',
			'assigned_projects', 'assigned_projects_count',
			'assigned_tasks', 'assigned_tasks_count', 'assigned_tickets', 'assigned_tickets_count', 'ipCheck', 'general_setting',
			'shift_ended', 'is_off_day', 'can_overtime_clock_in', 'is_on_overtime_session', 'today_overtime_total', 'is_past_shift_while_clocked_in',
			'is_location_head', 'location_head_employee_count', 'can_manage_location_scope'));
	}



	public function clientDashboard()
	{
        // return 1;
        // Auth::logout();
        // return redirect()->back();

		$user = auth()->user();

		$client = Client::with('invoices', 'projects')->findOrFail($user->id);

		$paid_invoices = $client->invoices->where('status', 1);

		$paid_invoice_count = $paid_invoices->count();

		$unpaid_invoices = $client->invoices->where('status', 0);

		$unpaid_invoice_count = $unpaid_invoices->count();

		$completed_project_count = $client->projects->where('project_status', 'completed')->count();

		$in_progress_project_count = $client->projects->where('project_status', 'in_progress')->count();

		$invoice_paid_amount_raw = $paid_invoices->sum('grand_total');

		$invoice_unpaid_amount_raw = $unpaid_invoices->sum('grand_total');

		if (config('variable.currency_format') == 'suffix')
		{
			$invoice_paid_amount = $invoice_paid_amount_raw . config('variable.currency');
			$invoice_unpaid_amount = $invoice_unpaid_amount_raw . config('variable.currency');

		} else
		{
			$invoice_paid_amount = config('variable.currency') . $invoice_paid_amount_raw;
			$invoice_unpaid_amount = config('variable.currency') . $invoice_unpaid_amount_raw;
		}


		return view('dashboard.client_dashboard', compact('user', 'client',
			'paid_invoice_count', 'unpaid_invoice_count', 'completed_project_count', 'in_progress_project_count',
			'invoice_paid_amount', 'invoice_unpaid_amount'));
	}

	public function clientProfile()
	{
		$user = auth()->user();
		if ($user->role_users_id == 3)
		{
			return view('profile.client_profile', compact('user'));
		}

		return redirect('profile');
	}
}


