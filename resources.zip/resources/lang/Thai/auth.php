<?php

return array (
  'failed' => '',
);
